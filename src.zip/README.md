Codul a fost documentat de pe:
-https://stackoverflow.com/
-https://www.tutorialspoint.com/
-https://pubs.opengroup.org/onlinepubs/

Functia int open(const char *filename, int flags, ...) a fost implementata folosinf Chat gpt.
Functai malloc si free au fost luate in intregime de pe -https://stackoverflow.com/
